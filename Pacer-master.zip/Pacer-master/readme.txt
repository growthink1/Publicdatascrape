Enter urls in urls.txt
Make sure there are no empty lines, including at the end of the file
Make sure the urls are inputted in exactly this format: https://ecf.txnb.uscourts.gov
Do not put a "/" at the end of the url

Does not work for districts that use a different template. 
For example, https://ecf.almd.uscourts.gov/cgi-bin/iquery.pl
Running a query through that district doesn't even list any chapters, so this program will not be able to parse through that district.
